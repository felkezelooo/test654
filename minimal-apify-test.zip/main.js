const Apify = require('apify');
const { Actor } = Apify;

// This is a minimal test actor to verify Apify deployment
async function main() {
    console.log('Starting minimal test actor');
    
    // Get input
    const input = await Actor.getInput() || {};
    console.log('Actor input:');
    console.log(JSON.stringify(input, null, 2));
    
    // Do some minimal work
    console.log('Processing...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Save output
    await Actor.setValue('OUTPUT', {
        message: 'Minimal test actor completed successfully',
        inputReceived: input,
        timestamp: new Date().toISOString()
    });
    
    console.log('Minimal test actor finished');
}

// Run the actor
Actor.main(main);
