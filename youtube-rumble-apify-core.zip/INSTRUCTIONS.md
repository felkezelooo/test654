# YouTube & Rumble View Bot - Apify Actor

This document provides instructions for using the YouTube & Rumble View Bot Apify actor, which has been adapted from the original software to run on the Apify platform with full residential proxy support and country selection capabilities.

## Key Features

- **All Premium Features Enabled**: All premium features are enabled by default without any restrictions, API keys, or login requirements
- **Residential Proxy Support**: Full integration with Apify's residential proxies with country selection
- **Multi-Platform Support**: Works with both YouTube and Rumble videos
- **Configurable Options**: All original software options are available and configurable in Apify

## Files Included

- `main.js` - The main actor code
- `INPUT_SCHEMA.json` - Defines all configurable options in the Apify UI
- `package.json` - Node.js dependencies
- `Apify.json` - Actor configuration
- `Dockerfile` - Container configuration for Apify
- `README.md` - Comprehensive documentation
- `test.js` - Test script for local validation

## Deployment Instructions

### Option 1: Using Apify Console

1. Log in to your Apify account
2. Create a new actor
3. Upload all the files from this package
4. Build the actor
5. Configure your input parameters
6. Run the actor

### Option 2: Using Apify CLI

1. Install Apify CLI: `npm install -g apify-cli`
2. Log in to your Apify account: `apify login`
3. Navigate to the actor directory
4. Push to Apify: `apify push`

## Configuration Options

All options from the original software are available and can be configured through the Apify UI:

### Video Settings
- **videoUrls**: List of YouTube or Rumble video URLs to view
- **watchTimePercentage**: Percentage of the video to watch (30-100%)

### Proxy Settings
- **useProxies**: Whether to use proxies for viewing videos
- **proxyUrls**: Optional list of custom proxy URLs
- **proxyCountry**: Country code for Apify residential proxies (e.g., US, GB, DE)
- **proxyGroups**: Apify proxy groups to use

### Browser Settings
- **headless**: Run browsers in headless mode
- **concurrency**: Number of concurrent browser instances
- **concurrencyInterval**: Interval between starting new browser instances
- **timeout**: Page load timeout in seconds

### Ad Settings
- **maxSecondsAds**: Maximum seconds to wait for ads
- **skipAdsAfter**: Skip ads after these many seconds
- **autoSkipAds**: Automatically skip ads when possible

### System Settings
- **stopSpawningOnOverload**: Stop spawning new instances if system is overloaded
- **disableProxyTests**: Skip testing proxies before using them
- **useAV1**: Use AV1 video codec when available

## Important Notes

1. All premium features are enabled by default - no API keys or logins required
2. For best results with residential proxies, specify a country code
3. Adjust concurrency based on your Apify subscription limits
4. The actor automatically handles proxy testing and management

## Troubleshooting

- If videos don't load, try increasing the timeout setting
- If proxies fail, try different countries or proxy groups
- For performance issues, reduce concurrency
- Check actor logs for detailed error messages
