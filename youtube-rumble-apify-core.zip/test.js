// Test script for YouTube & Rumble View Bot Apify actor
// This script simulates a basic run of the actor with minimal configuration

const Apify = require('apify');
const { Actor } = Apify;

// Mock Actor.getInput() to simulate user input
Actor.getInput = async () => {
  return {
    videoUrls: [
      'https://www.youtube.com/watch?v=dQw4w9WgXcQ'  // Test with a sample YouTube video
    ],
    watchTimePercentage: 50,
    headless: true,
    concurrency: 1,
    useProxies: false,  // Disable proxies for local testing
    timeout: 60
  };
};

// Mock Actor.setValue() to capture results
Actor.setValue = async (key, value) => {
  console.log(`Actor.setValue('${key}') called with:`, JSON.stringify(value, null, 2));
  return true;
};

// Mock createProxyConfiguration
Actor.createProxyConfiguration = async (options) => {
  console.log('Creating proxy configuration with options:', JSON.stringify(options, null, 2));
  return {
    newUrl: async () => 'http://mock-proxy:8080'
  };
};

// Mock Actor.isAtHome()
Actor.isAtHome = () => false;

// Run the main function from our actor
require('./main.js');
